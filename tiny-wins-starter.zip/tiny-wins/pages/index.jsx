
import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Footprints, Sandwich, Settings, RotateCcw, Check, Flame, Trophy, Info, Stethoscope } from "lucide-react";

// ---------------------------------------------
// Tiny Wins – MVP (Next.js pages router)
// ---------------------------------------------

const VERY_LIMITED_MOVE_CHALLENGES = [
  "Raise one arm overhead for 10 seconds, relax; repeat 5 times each side.",
  "Ankle circles: 10 each side while seated.",
  "Seated march: lift one knee then the other, 10 times total.",
  "Neck turns: look left and right gently 5 times.",
  "Seated calf pumps: press toes down and up 15 times.",
  "If safe, stand up once more today than usual.",
  "During TV ads, squeeze a cushion between your knees for 10 seconds × 5.",
  "Wall or counter push: 3–5 gentle reps.",
  "Shoulder rolls: 10 forward, 10 back.",
  "Breathing reset: 5 slow deep breaths before a meal.",
];

const BEGINNER_MOVE_CHALLENGES = [
  "Stand up during the next TV ad break.",
  "If you use the stairs, go up and down one extra time.",
  "While the kettle boils, do 5 counter push-ups.",
  "Carry a water bottle on your next short walk.",
  "Park one row farther away than usual.",
  "Do 10 seated marches while watching a video.",
  "Stretch your arms overhead for 20 seconds, twice today.",
  "Do 8 slow sit-to-stands from a chair.",
  "Walk to the end of your street and back.",
  "Roll your ankles and wrists for 30 seconds to loosen up.",
];

const MODERATE_MOVE_CHALLENGES = [
  "Add 2–3 minutes to your usual walk.",
  "Climb two extra flights of stairs today (split up is fine).",
  "Do 10 counter push-ups across the day.",
  "Carry a light bag or water bottle on a short walk.",
  "Stand and stretch for 60 seconds every hour you’re seated.",
  "Do 12 slow sit-to-stands across the day.",
  "Walk a slightly longer route to the shop.",
  "Calf raises while brushing your teeth: 10 reps.",
  "Hip circles while the kettle boils: 10 each way.",
  "One extra errand on foot if possible.",
];

const VERY_LIMITED_EAT_CHALLENGES = [
  "Leave two comfortable bites from one meal.",
  "Order two burgers instead of three.",
  "Swap one coke for water today.",
  "Say ‘no thanks’ to one extra sauce sachet.",
  "Ask for regular chips instead of large.",
  "Pause halfway through a meal and check in for 10 seconds.",
  "Add one piece of fruit sometime today.",
  "Choose one fewer slice/piece than usual.",
  "Have mayo/ketchup on the side and dip lightly.",
  "Drink a glass of water before one meal.",
];

const BEGINNER_EAT_CHALLENGES = [
  "Leave a couple of bites from one meal today.",
  "Swap one coke for water or tea.",
  "If you’d order three items, order two.",
  "Go for regular chips instead of large.",
  "Split a dessert or save half for later.",
  "Pause mid-meal; if you’re satisfied, stop there.",
  "Ask for sauces on the side and dip lightly.",
  "Drink a full glass of water before eating.",
  "Add a veg or salad portion once today.",
  "Eat a little slower—put cutlery down between bites.",
];

const MODERATE_EAT_CHALLENGES = [
  "Order two burgers instead of three, or one instead of two.",
  "Swap one sugary drink for water/tea/coffee.",
  "Regular chips instead of large; skip the extra salt.",
  "Leave the last two bites from any meal.",
  "Choose grilled/baked once today.",
  "Half your sauce or cheese portion once today.",
  "If snacking at night, switch one snack to fruit or yoghurt.",
  "Drink water first, then decide if you want more.",
  "Share a side rather than getting your own.",
  "Eat a little slower—put cutlery down between bites.",
];

const ENCOURAGEMENTS = [
  "One step today beats ten tomorrow.",
  "Tiny changes add up. You’re doing great.",
  "Consistency over intensity.",
  "You don’t need perfect. You just need today.",
  "Progress, not perfection.",
  "Every choice is a vote for your future self.",
  "Start where you are. Use what you have.",
];

function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    if (typeof window === "undefined") return initialValue;
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }, [key, value]);
  return [value, setValue];
}

function useDailyChallenge() {
  const [seed, setSeed] = useLocalStorage("tw-seed", Date.now());
  const [moveDone, setMoveDone] = useLocalStorage("tw-move-done", false);
  const [eatDone, setEatDone] = useLocalStorage("tw-eat-done", false);
  const [level] = useLocalStorage("tw-level", "very-limited");

  const rng = useMemo(() => {
    let s = seed % 2147483647;
    return () => (s = (s * 48271) % 2147483647);
  }, [seed]);

  const pick = (list) => {
    const index = rng() % list.length;
    return list[index];
  };

  const challengeBank = {
    "very-limited": { move: VERY_LIMITED_MOVE_CHALLENGES, eat: VERY_LIMITED_EAT_CHALLENGES },
    beginner: { move: BEGINNER_MOVE_CHALLENGES, eat: BEGINNER_EAT_CHALLENGES },
    moderate: { move: MODERATE_MOVE_CHALLENGES, eat: MODERATE_EAT_CHALLENGES },
  };

  const active = challengeBank[level] || challengeBank["very-limited"];
  const move = useMemo(() => pick(active.move), [seed, level]);
  const eat = useMemo(() => pick(active.eat), [seed, level]);
  const encouragement = useMemo(() => pick(ENCOURAGEMENTS), [seed]);

  const reroll = () => {
    setSeed(Date.now());
    setMoveDone(false);
    setEatDone(false);
  };

  return { move, eat, encouragement, moveDone, eatDone, setMoveDone, setEatDone, reroll };
}

function StreakBar({ completedToday }) {
  const [streak, setStreak] = useLocalStorage("tw-streak", 0);
  const [lastCompletion, setLastCompletion] = useLocalStorage("tw-last", "");

  const today = new Date().toDateString();

  useEffect(() => {
    if (completedToday && lastCompletion !== today) {
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      const nextStreak = lastCompletion === yesterday ? streak + 1 : 1;
      setStreak(nextStreak);
      setLastCompletion(today);
    }
  }, [completedToday]);

  const pct = Math.min(100, (streak % 7) * (100 / 7));

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Flame className="h-5 w-5" />
          <CardTitle className="text-base">Streak</CardTitle>
          <Badge variant="secondary" className="ml-auto">{streak} day{streak === 1 ? "" : "s"}</Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <Progress value={pct} />
        <p className="text-xs text-slate-500 mt-2">Every 7 days, you level up your flame 🔥</p>
      </CardContent>
    </Card>
  );
}

function Header({ tab, setTab }) {
  const tabs = [
    { key: "home", label: "Home", icon: Sparkles },
    { key: "challenge", label: "Daily", icon: Trophy },
    { key: "progress", label: "Progress", icon: Footprints },
    { key: "about", label: "About", icon: Info },
    { key: "clinicians", label: "For Clinicians", icon: Stethoscope },
    { key: "settings", label: "Settings", icon: Settings },
  ];
  return (
    <div className="sticky top-0 z-10 backdrop-blur bg-white/70 border-b">
      <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
        <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}>
          <div className="font-bold text-xl">Tiny Wins</div>
          <div className="text-xs text-slate-500 -mt-1">Move a little more · Eat a little less</div>
        </motion.div>
        <div className="ml-auto flex gap-1">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <Button key={t.key} variant={tab === t.key ? "default" : "ghost"} onClick={() => setTab(t.key)} className="gap-2">
                <Icon className="h-4 w-4" /> {t.label}
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function TinyWinsApp() {
  const [tab, setTab] = useState("home");
  const { move, eat, encouragement, moveDone, eatDone, setMoveDone, setEatDone, reroll } = useDailyChallenge();
  const [completedToday, setCompletedToday] = useState(false);

  // Accessibility
  const [largeText, setLargeText] = useLocalStorage("tw-a11y-large", false);
  const [highContrast, setHighContrast] = useLocalStorage("tw-a11y-contrast", false);

  useEffect(() => {
    if (moveDone || eatDone) setCompletedToday(true);
  }, [moveDone, eatDone]);

  return (
    <div className={`min-h-screen ${highContrast ? 'bg-white text-black' : 'bg-gradient-to-b from-slate-50 to-white text-slate-800'} ${largeText ? 'text-[18px]' : ''}`}>
      <Header tab={tab} setTab={setTab} />
      <main className="max-w-3xl mx-auto px-4 py-6 grid gap-4">
        {tab === "home" && <Home setTab={setTab} encouragement={encouragement} />}
        {tab === "challenge" && (
          <DailyChallenge
            move={move}
            eat={eat}
            moveDone={moveDone}
            eatDone={eatDone}
            setMoveDone={setMoveDone}
            setEatDone={setEatDone}
            reroll={reroll}
            onComplete={() => setCompletedToday(true)}
          />
        )}
        {tab === "progress" && <ProgressView />}
        {tab === "about" && <About />}
        {tab === "clinicians" && <ClinicianInfo />}
        {tab === "settings" && (
          <SettingsView
            largeText={largeText}
            setLargeText={setLargeText}
            highContrast={highContrast}
            setHighContrast={setHighContrast}
          />
        )}
        <StreakBar completedToday={completedToday} />
      </main>
      <footer className="max-w-3xl mx-auto px-4 pb-10 pt-2 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} Tiny Wins · Built for people who feel left out by traditional fitness apps.
      </footer>
    </div>
  );
}

function Home({ setTab, encouragement }) {
  return (
    <>
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="bg-white border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-2xl">Start tiny. Win daily.</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4">
            <p className="text-slate-600">
              No diets. No gyms. No guilt. Tiny Wins helps you build confidence with small, doable actions:
              move a little more and eat a little less—at your pace.
            </p>
            <div className="flex flex-wrap gap-2">
              <Badge>Beginner friendly</Badge>
              <Badge>Very limited mobility options</Badge>
              <Badge>Non-judgmental</Badge>
              <Badge>Micro-habits</Badge>
            </div>
            <div className="flex gap-3">
              <Button onClick={() => setTab("challenge")} className="gap-2"><Trophy className="h-4 w-4"/> Today’s tiny wins</Button>
              <Button variant="outline" onClick={() => setTab("about")} className="gap-2"><Info className="h-4 w-4"/> Read the story</Button>
            </div>
            <SafetyCard />
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Today’s encouragement</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg">{encouragement}</p>
          </CardContent>
        </Card>
      </motion.div>
    </>
  );
}

function DailyChallenge({ move, eat, moveDone, eatDone, setMoveDone, setEatDone, reroll, onComplete }) {
  useEffect(() => {
    if (moveDone || eatDone) onComplete?.();
  }, [moveDone, eatDone]);

  const completeBoth = moveDone && eatDone;
  const progress = (Number(moveDone) + Number(eatDone)) * 50;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid gap-4">
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            <CardTitle className="text-base">Today’s tiny wins</CardTitle>
            <Button variant="ghost" onClick={reroll} className="ml-auto gap-2"><RotateCcw className="h-4 w-4"/>New set</Button>
          </div>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid md:grid-cols-2 gap-4">
            <TaskCard
              icon={Footprints}
              title="Move a bit more"
              text={move}
              done={moveDone}
              onDone={() => setMoveDone(true)}
              onUndo={() => setMoveDone(false)}
            />
            <TaskCard
              icon={Sandwich}
              title="Eat a bit less"
              text={eat}
              done={eatDone}
              onDone={() => setEatDone(true)}
              onUndo={() => setEatDone(false)}
            />
          </div>
          <div>
            <Progress value={progress} />
            <p className="text-xs text-slate-500 mt-2">Complete one for a win. Do both for a double win.</p>
          </div>
          {completeBoth && (
            <div className="text-sm">✨ Nice! Optional bonus: walk to the nearest corner and back, or leave two extra bites tonight.</div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

function TaskCard({ icon: Icon, title, text, done, onDone, onUndo }) {
  return (
    <Card className={`border ${done ? "border-emerald-300" : "border-transparent"} shadow-sm`}>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Icon className="h-5 w-5" />
          <CardTitle className="text-base">{title}</CardTitle>
          {done && <Badge className="ml-auto" variant="secondary">Done</Badge>}
        </div>
      </CardHeader>
      <CardContent className="grid gap-3">
        <p>{text}</p>
        <div className="flex gap-2">
          {!done ? (
            <Button onClick={onDone} className="gap-2"><Check className="h-4 w-4"/> I did this</Button>
          ) : (
            <Button variant="outline" onClick={onUndo} className="gap-2"><RotateCcw className="h-4 w-4"/> Undo</Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function ProgressView() {
  const [wins, setWins] = useLocalStorage("tw-wins", 0);
  const [moveDone] = useLocalStorage("tw-move-done", false);
  const [eatDone] = useLocalStorage("tw-eat-done", false);

  useEffect(() => {
    const today = new Date().toDateString();
    const key = `tw-win-mark-${today}`;
    const marked = window.localStorage.getItem(key);
    const any = moveDone || eatDone;
    if (any && !marked) {
      setWins((w) => w + 1);
      window.localStorage.setItem(key, "1");
    }
  }, [moveDone, eatDone]);

  const weeklyWins = Math.min(7, wins % 8 || wins);
  const pct = Math.min(100, (weeklyWins / 7) * 100);

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid gap-4">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl">Your progress</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3">
          <div className="grid md:grid-cols-3 gap-3">
            <Stat label="Total wins" value={wins} />
            <Stat label="This week" value={`${weeklyWins}/7 days`} />
            <Stat label="Longest streak" value={<LongestStreak />} />
          </div>
          <Progress value={pct} />
          <p className="text-xs text-slate-500">Keep showing up. Tiny steps compound.</p>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Ideas that fit your life</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-6 leading-7 text-sm">
            <li>Use your stairs: one extra up-and-down when you go to the bathroom.</li>
            <li>Stand during ad breaks.</li>
            <li>Order two burgers instead of three.</li>
            <li>Leave a couple of bites; share or save for later.</li>
            <li>Carry water bottles on a short walk for light resistance.</li>
          </ul>
          <SafetyCard compact />
        </CardContent>
      </Card>
    </motion.div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="p-4 rounded-2xl border bg-white">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
    </div>
  );
}

function LongestStreak() {
  const [streak] = useLocalStorage("tw-streak", 0);
  const [best, setBest] = useLocalStorage("tw-best", 0);

  useEffect(() => {
    if (streak > best) setBest(streak);
  }, [streak]);

  return <span>{best} days</span>;
}

function SettingsView({ largeText, setLargeText, highContrast, setHighContrast }) {
  const [level, setLevel] = useLocalStorage("tw-level", "very-limited");
  const [reminders, setReminders] = useLocalStorage("tw-reminders", true);

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid gap-4">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl">Preferences</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div>
            <div className="text-sm font-medium mb-1">Comfort level</div>
            <div className="flex flex-wrap gap-2">
              {[
                { key: "very-limited", label: "Very limited mobility" },
                { key: "beginner", label: "Beginner" },
                { key: "moderate", label: "Moderate" },
              ].map((opt) => (
                <Button
                  key={opt.key}
                  variant={level === opt.key ? "default" : "outline"}
                  onClick={() => setLevel(opt.key)}
                >
                  {opt.label}
                </Button>
              ))}
            </div>
            <p className="text-xs text-slate-500 mt-2">This will tailor your daily ideas.</p>
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Reminders</div>
            <div className="flex gap-2">
              <Button variant={reminders ? "default" : "outline"} onClick={() => setReminders(true)}>On</Button>
              <Button variant={!reminders ? "default" : "outline"} onClick={() => setReminders(false)}>Off</Button>
            </div>
            <p className="text-xs text-slate-500 mt-2">Push/email reminders will be optional later. (Mockup)</p>
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Accessibility</div>
            <div className="grid gap-2">
              <div className="flex items-center gap-2">
                <span className="text-sm w-32">Large text</span>
                <Button variant={largeText ? "default" : "outline"} onClick={() => setLargeText(true)}>On</Button>
                <Button variant={!largeText ? "default" : "outline"} onClick={() => setLargeText(false)}>Off</Button>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm w-32">High contrast</span>
                <Button variant={highContrast ? "default" : "outline"} onClick={() => setHighContrast(true)}>On</Button>
                <Button variant={!highContrast ? "default" : "outline"} onClick={() => setHighContrast(false)}>Off</Button>
              </div>
            </div>
            <p className="text-xs text-slate-500 mt-2">These options change how the app looks to make it easier to read.</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function About() {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid gap-4">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl">Why Tiny Wins exists</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <p>
            Tiny Wins is for people who feel left out by traditional fitness: those who can’t or don’t want to
            overhaul their diet or start heavy workouts. We start with what you already do and add small,
            achievable nudges. The programme is built with input from behaviour change psychology, gentle nutrition,
            and low-impact movement principles.
          </p>
          <SafetyCard />
          <FounderNote />
        </CardContent>
      </Card>
    </motion.div>
  );
}

function FounderNote() {
  return (
    <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
      <div className="text-sm font-semibold mb-1">Founder note</div>
      <p className="text-sm leading-6">
        I struggle to find time for the gym and I hate dieting. What’s worked for me is giving up coke, walking daily,
        doing countertop push-ups, and trying fasting by starting small. Tiny Wins is built on that personal experience:
        gentle, doable steps that stack up over time.
      </p>
    </div>
  );
}

function ClinicianInfo() {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid gap-4">
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl">For Clinicians</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <p className="text-sm">
            <strong>Tiny Wins</strong> is a gentle micro-behaviour programme for patients who feel excluded by traditional
            fitness and dieting. It offers one movement nudge and one eating nudge per day (very limited mobility options included).
            No calorie counting, no gym. Habits are stored locally; no login required.
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl border bg-white">
              <div className="text-sm font-semibold mb-2">At-a-glance</div>
              <ul className="list-disc pl-5 text-sm leading-6">
                <li>Audience: adults with very limited mobility / overwhelmed by conventional advice.</li>
                <li>Daily: 1 movement nudge + 1 food nudge; simple streaks; no weight entry required.</li>
                <li>Safety: start small; stop with pain/dizziness/chest discomfort; consult GP if unsure.</li>
                <li>Privacy: no login; local-only data by default.</li>
              </ul>
            </div>

            <div className="p-4 rounded-2xl border bg-white">
              <div className="text-sm font-semibold mb-2">Recommend in clinic</div>
              <p className="text-sm leading-6">
                Suggested script: “This is a gentle, tiny-steps programme called <em>Tiny Wins</em>. It doesn’t require dieting or a gym.
                It suggests small movement and eating tweaks that fit everyday life. Many people find it a kinder way to start.”
              </p>
              <div className="mt-3">
                <Button className="gap-2" onClick={() => window.print()}>Print one-pager</Button>
              </div>
            </div>
          </div>

          <SafetyCard />
        </CardContent>
      </Card>
    </motion.div>
  );
}

function SafetyCard({ compact = false }) {
  return (
    <div className={`p-4 rounded-2xl ${compact ? 'bg-slate-50 border' : 'bg-blue-50 border border-blue-200'}`}>
      <div className="text-sm font-semibold mb-1">Safety first</div>
      <p className="text-xs leading-6 text-slate-600">
        Start small and listen to your body. If you have medical concerns, pain, dizziness, chest discomfort, or you’re
        unsure what’s right for you, speak to your GP or healthcare professional before increasing activity or changing
        your eating pattern.
      </p>
    </div>
  );
}
