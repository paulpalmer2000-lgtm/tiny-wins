
export function Badge({ children, className = "", variant = "default" }) {
  const styles = {
    default: "bg-slate-900 text-white",
    secondary: "bg-slate-200 text-slate-800"
  };
  return <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs ${styles[variant]} ${className}`}>{children}</span>;
}
