
export function Button({ children, className = "", variant = "default", onClick, ...props }) {
  const base = "inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-medium transition border shadow-sm";
  const styles = {
    default: "bg-black text-white hover:opacity-90 border-black",
    outline: "bg-white text-black border-slate-300 hover:bg-slate-50",
    ghost: "bg-transparent text-black border-transparent hover:bg-slate-100",
    secondary: "bg-slate-800 text-white border-slate-800 hover:opacity-90"
  };
  return (
    <button onClick={onClick} className={`${base} ${styles[variant] || styles.default} ${className}`} {...props}>
      {children}
    </button>
  );
}
